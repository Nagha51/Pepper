var x;
var ip = "192.168.8.105";
var session;

$(document).ready(function(){
	// alert("coucou")
	 // window.location.reload(true)
	// init()
	// $(".example").TimeCircles().end().then(alert("coucou"))
	// $(".TimeCircles").end().fadeOut()

	// $(".start").on('click ', function(){start()});
	// $(".stop").on('click ', function(){stop()});
});


function createSession(callback) {
	try {
		QiSession( function (s) {
			console.log('connected!');
			session = s;
			callback();
		 },disconnected,ip);
		// });
	}catch (err) {
		alert(error)
	  	console.log("Error when initializing QiSession: " + err.message);
	  	console.log("Make sure you load this page from the robots server.");
	}
}

function disconnected() {
  console.log("disconnected");
}
function toggleImage() {
	$(".iddle").fadeToggle(500);
	$(".TimeCircles").fadeToggle(1000);
}

function init(){
	$(".TimeCircles").TimeCircles({
		start:false,
		count_past_zero:true,
		time: {
			Days: {show:false},
			Hours: {show:false},
			Minutes: {show:false},
			Seconds: {show:true, text:""}
		},
		total_duration: 3.1,
		direction:"Counter-clockwise"
	}).addListener(countdownComplete)
	// }).addListener(countdownComplete).end().promise().done(
	// 		function(){
	// 			setTimeout(function()
	// 			{
	// 	  			createSession(function(){
	// 					chronoLoaded();
	// 				});
	// 			}, 1500);
	// 		}
	// 	)
	// $(".iddle").hide()
	// $(".TimeCircles").show()
	$(".iddle").show()
	$(".TimeCircles").hide()
	setTimeout(function()
				{
		  			createSession(function(){
						chronoLoaded();
					});
				}, 4000);
	// );
}

function chronoLoaded(){
	// alert("chronoFunction")
	console.log("chronoLoaded launch")
	session.service('ALMemory').then(
		function(memory)
		{
			memory.raiseEvent("TabletChronoLoaded","1");
			console.log("Event TabletChronoLoaded Raised")
			alert("Event TabletChronoLoaded Raised")
		}, function (error)
		{
        	console.log(error);
        	alert(error)
		}
	);
}

function start(){
	$(".iddle").fadeToggle(500);
	$(".TimeCircles").fadeToggle(1000).promise().done(
		function()
		{
			setTimeout(function()
			{
		  		$(".TimeCircles").TimeCircles().start();
			}, 1500);
		}
	);
}

function stop(){
	$(".TimeCircles").TimeCircles().stop();
}

function countdownComplete(unit, value, total){
	if (total < 0){
		stop();
		$(this).fadeOut('slow');
		session.service('ALMemory').then(
			function(memory)
			{
        		memory.raiseEvent("TabletChronoEnded","1");
			}, function (error)
			{
		        console.log(error);
    		}
    	);
	}
}

