// var ip = "192.168.8.105";
// var session;
var timerID;

$(document).ready(function(){
	// init()
	//.fadeOut()
	// $(".start").on('click ', function(){startRandom()});
	// $(".stop").on('click ', function(){stopRandom()});
});

function toggleImage(number) {
	number = 1
	var imgID = "#img" + number
	$(imgID).fadeToggle(2000);
}

function init(){
	// $(".img").hide()
	setTimeout(function()
	{
		toggleImage(1);
	}, 500);
}

function startRandom() {
	timerID = setInterval(randomColor,500)
}

function stopRandom() {
	clearInterval(timerID)
}

function randomColor() {
    var color = '#';
    var letters = ['000000','FF0000','00FF00','0000FF','FFFF00','00FFFF','FF00FF','C0C0C0'];
    color += letters[Math.floor(Math.random() * letters.length)];
    $("body").css({"background-color": color})
}

function createSession(callback) {
	try {
		QiSession( function (s) {
			console.log('connected!');
			session = s;
			callback();
		 // },disconnected,ip);
		});
	}catch (err) {
		alert(error)
	  	console.log("Error when initializing QiSession: " + err.message);
	  	console.log("Make sure you load this page from the robots server.");
	}
}

function disconnected() {
  console.log("disconnected");
}



